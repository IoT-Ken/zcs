#!/bin/bash

# bash strict mode
set -euo pipefail

cd "$(dirname "${0}")" &&
./zcs-firstboot "$@"

