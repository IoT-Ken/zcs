#!/bin/bash

# bash strict mode
set -euo pipefail

: "${PREFIX:=.}"
: "${FIRSTBOOT_FILE:=${PREFIX}/firstboot_done}"
: "${IOTC_AGENT_UNINSTALL:="/opt/vmware/iotc-agent/uninstall.sh"}"
: "${IOTC_DIR:=${PREFIX}/iotc-sdk}"

cd "$(dirname "${0}")"

[ -f "${FIRSTBOOT_FILE}" ] && rm "${FIRSTBOOT_FILE}" 
[ -d "${IOTC_DIR}" ] && rm -rf ${IOTC_DIR}

if [ -f "${IOTC_AGENT_UNINSTALL}" ]
then
    echo "Un-installing IoTC Agent"
    ${IOTC_AGENT_UNINSTALL}
fi

./zcs-firstboot "$@"

